﻿create proc PolicyEn.UpdateStatus 
@sta varchar(50),
@cname VARCHAR(50),
@cdob DATE,
@cgen VARCHAR(50),
@nom VARCHAR(50),
@rel VARCHAR(50),
@csmoke VARCHAR(50),
@cadd VARCHAR(50),
@cphno VARCHAR(50),
@premium VARCHAR(50),
@polno INT 
as
update PolicyEn.[Status] set status = 'Approved' where policyNo = @polNo;  

 UPDATE [PolicyEn].[Customers] SET Age = DATEDIFF(year,@cdob,GETDATE())  FROM [PolicyEn].[Customers] C1 
									INNER JOIN  [PolicyEn].[Policy] P1 ON (C1.CustId = P1.CustId) 
									WHERE P1.PolicyNumber IN (@polno);
 UPDATE [PolicyEn].[Customers] SET CustName=@cname,Smoker=@csmoke,DOB=@cdob,CustAddress=@cadd,
									CustPhoneNo=@cphno,CustGender=@cgen,Relation=@rel,Nominee=@nom,
									Premium_payment_freq=@premium  FROM [PolicyEn].[Customers] C1 
									INNER JOIN  [PolicyEn].[Policy] P1 ON (C1.CustId = P1.CustId)
									WHERE P1.PolicyNumber IN (@polno);

select * from PolicyEn.[Status]