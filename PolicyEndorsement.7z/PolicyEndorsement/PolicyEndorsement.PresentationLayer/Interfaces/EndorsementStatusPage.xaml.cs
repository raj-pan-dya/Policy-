﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using PolicyEndorsement.BusinessLogicLayer;
using PolicyEndorsement.Entities;
using PolicyEndorsement.Exceptions;

namespace PolicyEndorsement.PresentationLayer.Interfaces
{
    /// <summary>
    /// Interaction logic for EndorsementStatusPage.xaml
    /// </summary>
    public partial class EndorsementStatusPage : UserControl, ISwitchable
    {
        static PolicyBL polBL = new PolicyBL();

        IEnumerable<EndorsementStatus> status = polBL.SelectUpdateDetailsBL();

        public EndorsementStatusPage()
        {
            InitializeComponent();
            PopulateUI();
        }

        public void PopulateUI()
        {
            dgStatus.ItemsSource = status;
            cmbBoxPolicyNo.ItemsSource = status;
            cmbBoxPolicyNo.DisplayMemberPath = "PolicyNo";
        }

        private void btnHome_Click(object sender, RoutedEventArgs e)
        {
            Switcher.Switch(new HomePage());
        }

        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            Switcher.Switch(new SearchPolicyPage());
        }

        public void UtilizeState(object state)
        {
            throw new NotImplementedException();
        }

        private void cmbBoxPolicyNo_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                var res = status.Where(s => s.PolicyNo == Convert.ToInt32(cmbBoxPolicyNo.Text));
                dgStatus.ItemsSource = res;
            }
            catch (PolicyException udex)
            {
                MessageBox.Show(udex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
