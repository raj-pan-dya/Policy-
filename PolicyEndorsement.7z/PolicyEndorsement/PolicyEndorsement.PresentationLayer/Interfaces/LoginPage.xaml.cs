﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using PolicyEndorsement.Entities;
using PolicyEndorsement.Exceptions;
using PolicyEndorsement.BusinessLogicLayer;


namespace PolicyEndorsement.PresentationLayer.Interfaces
{
    /// <summary>
    /// Interaction logic for LoginPage.xaml
    /// </summary>
    public partial class LoginPage : UserControl, ISwitchable
    {
        static PolicyBL polBL = new PolicyBL();

        bool adminButtonClicked = false;
        bool userButtonClicked = false;

        string access;

        public LoginPage()
        {
            InitializeComponent();
        }
        

        private bool ValidateFields()
        {
            bool isValid = true;

            StringBuilder sb = new StringBuilder();

            if (txtPassword.Password == string.Empty)
            {
                isValid = false;
                sb.Append(Environment.NewLine + "Please provide Password");
            }
            if (txtLoginId.Text == string.Empty)
            {
                isValid = false;
                sb.Append(Environment.NewLine + "Please provide LoginId");
            }
            if (isValid == false)
            {
                throw new PolicyException(sb.ToString());
            }
            return isValid;
        }

        
        private void btnLogin_Click(object sender, RoutedEventArgs e)
        {
            userButtonClicked = true;
            bool test = false;
            try
            {
                if (ValidateFields())
                {
                    

                    UserLogin objLogin = new UserLogin
                    {
                        LoginID = Convert.ToInt32(txtLoginId.Text),
                        Password = txtPassword.Password
                    };

                    test = polBL.LoginBL(objLogin);
                    
                    if (test)
                    {
                        
                        Switcher.Switch(new HomePage());

                    }
                    else
                    {
                        MessageBox.Show("INCORRECT PASSWORD OR USER ID", "Authentication Failed");
                        txtLoginId.Text = string.Empty;
                        txtPassword.Password = string.Empty;
                    }
                    
                }


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public string Access()
        {
            
            if (adminButtonClicked == true)
            {
                access = "Admin";
            }
            if (userButtonClicked == true)
            {
                access = "User";
            }
            return access;
        }

        public void UtilizeState(object state)
        {
            throw new NotImplementedException();
        }

        private void BtnAdminLogin_Click(object sender, RoutedEventArgs e)
        {
            adminButtonClicked = true;
            bool test = false;
            try
            {
                if (ValidateFields())
                {
                    UserLogin objLogin = new UserLogin
                    {
                        LoginID = Convert.ToInt32(txtLoginId.Text),
                        Password = txtPassword.Password
                    };

                    test = polBL.LoginAdminBL(objLogin);

                    if (test)
                    {
                       
                        Switcher.Switch(new HomePage());
                    }
                    else
                    {
                        MessageBox.Show("INCORRECT PASSWORD OR USER ID", "Authentication Failed");
                        txtLoginId.Text = string.Empty;
                        txtPassword.Password = string.Empty;
                    }
                }


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
