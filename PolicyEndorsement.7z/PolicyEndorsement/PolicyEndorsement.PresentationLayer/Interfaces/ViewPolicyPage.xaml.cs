﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using PolicyEndorsement.Exceptions;
using PolicyEndorsement.Entities;
using PolicyEndorsement.BusinessLogicLayer;
using System.IO;
using Microsoft.Win32;

namespace PolicyEndorsement.PresentationLayer.Interfaces
{
    /// <summary>
    /// Interaction logic for ViewPolicyPage.xaml
    /// </summary>
    public partial class ViewPolicyPage : UserControl, ISwitchable
    {
        static PolicyBL polBL = new PolicyBL();

        CompleteDetails objDetails = new CompleteDetails();

        IEnumerable<Document> file = polBL.SelectDocBL();

        LoginPage login = new LoginPage();
        

        public ViewPolicyPage(CompleteDetails customer)
        {
           
           
            string access = login.Access();
            if (access == "User")
            {
                
                InitializeComponent();
                btnUpdateAdmin.Visibility = Visibility.Hidden;
                PopulateUI(customer);
                dgFileName.ItemsSource = file;

            }
            else
            {
                InitializeComponent();
                PopulateUI(customer);
                dgFileName.ItemsSource = file;
            }
        }


        private bool ValidatePol()
        {
            StringBuilder sb = new StringBuilder();

            bool validPol = true;

            if (txtCustomerName.Text == string.Empty)
            {
                validPol = false;
                sb.Append(Environment.NewLine + "Customer name should not be empty");
            }
            if (txtCustomerAge.Text == string.Empty)
            {
                validPol = false;
                sb.Append(Environment.NewLine + "Enter your Age");
            }
            if (txtGender.Text == string.Empty)

            {
                validPol = false;
                sb.Append(Environment.NewLine + "Gender is not Selected");
            }


            if (txtNominee.Text == string.Empty)
            {
                validPol = false;
                sb.Append(Environment.NewLine + "Enter Nominee Name");
            }

            if (txtRelation.Text == string.Empty)
            {
                validPol = false;
                sb.Append(Environment.NewLine + "Enter Your Relation");
            }
            if (txtSmoker.Text == string.Empty)
            {
                validPol = false;
                sb.Append(Environment.NewLine + "Enter weather you are smoker or not smoker");
            }
            if (txtAddress.Text == string.Empty)
            {
                validPol = false;
                sb.Append(Environment.NewLine + "Enter your address");
            }
            if (txtPolicyNumber.Text == string.Empty)
            {
                validPol = false;
                sb.Append(Environment.NewLine + "Enter Phone No");
            }
            if (txtPaymentFreq.Text == string.Empty)
            {
                validPol = false;
                sb.Append(Environment.NewLine + "Enter your premium payment frequency like monthly,quaterly and yearly");
            }

            if (validPol == false)
            {
                throw new PolicyException(sb.ToString());
            }

            return validPol;
        }

        public void PopulateUI(CompleteDetails customer)
        {
            try
            {
                txtPolicyNumber.Text = customer.PolicyNumber.ToString();
                txtProductLine.Text = customer.ProductLine.ToString();
                txtProductName.Text = customer.ProductName.ToString();
                txtCustomerName.Text = customer.CustomerName.ToString();
                txtCustomerAge.Text = customer.Age.ToString();
                txtDateOfBirth.Text = customer.CustDOB.ToString();
                txtGender.Text = customer.CustomerGender.ToString();
                txtNominee.Text = customer.Nominee.ToString();
                txtRelation.Text = customer.Relation.ToString();
                txtSmoker.Text = customer.CustSmoker.ToString();
                txtAddress.Text = customer.CustAddress.ToString();
                txtPhoneNo.Text = customer.CustPhoneNo.ToString();
                txtPaymentFreq.Text = customer.PremiumPayFrequency.ToString();
                polBL.ViewDetailsBL(customer);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (ValidatePol())
                {
                    Product objProd = new Product
                    {
                        ProductLine = txtProductLine.Text,
                        ProductName = txtProductName.Text
                    };

                    Policy objPolicy = new Policy
                    {
                        PolicyNumber = Convert.ToInt32(txtPolicyNumber.Text),
                    };

                    Customer objCust = new Customer
                    {
                        CustomerName = txtCustomerName.Text,
                        Age = Convert.ToInt32(txtCustomerAge.Text),
                        CustDOB = Convert.ToDateTime(txtDateOfBirth.Text),
                        CustomerGender = Convert.ToChar(txtGender.Text),
                        Nominee = txtNominee.Text,
                        Relation = txtRelation.Text,
                        CustSmoker = txtSmoker.Text,
                        CustAddress = txtAddress.Text,
                        CustPhoneNo = txtPhoneNo.Text,
                        PremiumPayFrequency = txtPaymentFreq.Text
                    };
                    polBL.UpdateBL(objCust, objProd, objPolicy);
                    MessageBox.Show("Update Succesfully");
                }


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }



        private void btnUploadDoc_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Stream checkStream = null;
                OpenFileDialog dlg = new OpenFileDialog();
                dlg.Multiselect = true;
                dlg.Filter = "All Image Files | *.*";
                Nullable<bool> result = dlg.ShowDialog();
                if (result == true)
                {
                    try
                    {
                        if ((checkStream = dlg.OpenFile()) != null)
                        {
                            var filename = dlg.FileName;
                            polBL.UploadBL(Convert.ToInt32(txtPolicyNumber.Text), filename);
                            dgFileName.ItemsSource = file;
                            MessageBox.Show("Successfully done", filename);
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: Could not read file from disk. Original error: " + ex.Message);
                    }
                }
                else
                {
                    MessageBox.Show("Problem occured, try again later");
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        

        private void btnStatus_Click(object sender, RoutedEventArgs e)
        {
            Switcher.Switch(new EndorsementStatusPage());
        }

        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            Switcher.Switch(new SearchPolicyPage());
        }

        public void UtilizeState(object state)
        {
            throw new NotImplementedException();
        }

        private void btnHome_Click(object sender, RoutedEventArgs e)
        {
            Switcher.Switch(new HomePage());
        }

        private void BtnUpdateAdmin_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (ValidatePol())
                {
                    Product objProd = new Product
                    {
                        ProductLine = txtProductLine.Text,
                        ProductName = txtProductName.Text
                    };

                    Policy objPolicy = new Policy
                    {
                        PolicyNumber = Convert.ToInt32(txtPolicyNumber.Text),
                    };

                    Customer objCust = new Customer
                    {
                        CustomerName = txtCustomerName.Text,
                        Age = Convert.ToInt32(txtCustomerAge.Text),
                        CustDOB = Convert.ToDateTime(txtDateOfBirth.Text),
                        CustomerGender = Convert.ToChar(txtGender.Text),
                        Nominee = txtNominee.Text,
                        Relation = txtRelation.Text,
                        CustSmoker = txtSmoker.Text,
                        CustAddress = txtAddress.Text,
                        CustPhoneNo = txtPhoneNo.Text,
                        PremiumPayFrequency = txtPaymentFreq.Text
                    };
                    polBL.UpdateStatusBL(objCust, objProd, objPolicy);
                    MessageBox.Show("Update Succesfully");
                }


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
