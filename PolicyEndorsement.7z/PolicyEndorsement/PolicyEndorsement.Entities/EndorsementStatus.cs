﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PolicyEndorsement.Entities
{
    public class EndorsementStatus
    {
        public int PolicyNo { get; set; }
        public string Fields { get; set; }
        public string Values { get; set; }
        public string Status { get; set; }
    }
}
